// Display Today's Date

const today = new Date();

const dateBox = document.getElementById("date");

if(dateBox){

dateBox.innerHTML = today.toDateString();

}

// AI Copilot Answers

function showAnswer(){

const question =
document.getElementById("question").value.toLowerCase();

const answer =
document.getElementById("answer");

if(question.includes("pump")){

answer.innerHTML = `
<h3>AI Response</h3>

<p>
Pump P-101 is not ready because its datasheet is missing.
Upload the datasheet to complete handover.
</p>`;

}

else if(question.includes("blocked")){

answer.innerHTML = `
<h3>AI Response</h3>

<p>
Compressor C-401 is blocked because
a Category A punch remains open.
</p>`;

}

else if(question.includes("ready")){

answer.innerHTML = `
<h3>AI Response</h3>

<p>
Pipeline PL-501 is fully ready for handover.
</p>`;

}

else{

answer.innerHTML=`
<h3>AI Response</h3>

<p>
Sorry, I couldn't understand the question.
Try asking about Pump, Ready or Blocked assets.
</p>`;

}

}