# ARIA - Asset Readiness Intelligence Advisor

## Internship Project

This project demonstrates a simple browser-based prototype of the ARIA system.

### Technologies Used

- HTML5
- CSS3
- JavaScript

### Screens

1. Dashboard
2. Asset 360
3. Gap Register
4. ARIA Copilot

### Features

- Dashboard with asset summary
- Asset detail page
- Gap Register
- AI explanation panel
- Navigation between screens
- Responsive card layout